
package proyectojava20;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


public class Proyectojava20 {


    public static void main(String[] args) throws IOException {
   
        int anchura = 800;                                                      // Anchura imagen
        int altura = 400;                                                       // Altura imagen
        
                                                                                // Recurso vacio por si más adelante nos interesa
        
        BufferedImage imagencacheada = new BufferedImage(anchura,altura,BufferedImage.TYPE_INT_RGB); // Creo una imagen con altura,anchura y color.
        
        Graphics2D graficos = imagencacheada.createGraphics();                  // Digo que dentro de esa imagen voy a pintar cosas
        
        graficos.setColor(Color.white);
        graficos.fillRect(0, 0, anchura,altura);    
        
        graficos.setColor(Color.red);                                         // Digo que lo que voy a pintar es de color rojo
        graficos.fillRect(20, 20, 300, 300);                     // Pinto un rectangulo
        
        graficos.setColor(Color.green);
        graficos.drawString("Programa de Alejandro", 300, 200);
        
        BufferedImage imagen = null;
        imagen = ImageIO.read(new File("\"C:\\Users\\Alejandro\\Documents\\NetBeansProjects\\Proyectojava20\\logos\""));
        graficos.drawImage(imagen, 0, 0, null);
       
       
        
        graficos.dispose();                                                     // Libero un recurso
        
        File archivo = new File("/guardado/primeraprueba1.png");                    // Apunto a un nuevo archivo
        ImageIO.write(imagencacheada,"png",archivo);          // Con la librería correspondiende guardo el png en el archivo
        
    }
    
}
