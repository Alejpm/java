/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectojava21;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.imageio.ImageIO;

/**
 *
 * @author Alejandro
 */
public class Proyectojava21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/cursojava", "cursojava", "cursojava");
            
            Statement peticion = conexion.createStatement();
            ResultSet resultado = (ResultSet) peticion.executeQuery("SELECT * FROM cursos");
            while(resultado.next()){
                System.out.println(resultado.getString(3));
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                
                int anchura = 800;                                                      // Anchura imagen
        int altura = 400;                                                       // Altura imagen
        
                                                                                // Recurso vacio por si más adelante nos interesa
        
        BufferedImage imagencacheada = new BufferedImage(anchura,altura,BufferedImage.TYPE_INT_RGB); // Creo una imagen con altura,anchura y color.
        
        Graphics2D graficos = imagencacheada.createGraphics();                  // Digo que dentro de esa imagen voy a pintar cosas
        
        graficos.setColor(Color.white);
        graficos.fillRect(0, 0, anchura,altura);    
        
        graficos.setColor(Color.white);                                         // Digo que lo que voy a pintar es de color rojo
        graficos.fillRect(20, 20, 300, 300);                     // Pinto un rectangulo
        
        graficos.setColor(Color.green);
        graficos.drawString("Programa de Alejandro", 300, 200);
        
        BufferedImage imagen = null;
        imagen = ImageIO.read(new File("\"C:\\Users\\Alejandro\\Documents\\NetBeansProjects\\Proyectojava20\\logos\""));
        graficos.drawImage(imagen, 0, 0, null);
       
       
        
        graficos.dispose();                                                     // Libero un recurso
        
        File archivo = new File("/guardado/primeraprueba1.png");                    // Apunto a un nuevo archivo
        ImageIO.write(imagencacheada,"png",archivo);          // Con la librería correspondiende guardo el png en el archivo
                
                
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            }
        }catch(Exception e){
            e.printStackTrace();
        }

    }
    
}
        // TODO code application logic here
    
    

