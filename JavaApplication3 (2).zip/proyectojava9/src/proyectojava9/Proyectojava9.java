
package proyectojava9;


public class Proyectojava9 {

 
    public static void main(String[] args) {
        
        for(int dia = 1;dia <=30;dia = dia + 1){
        
        System.out.println("Hoy es el dia "+dia+" del mes y lo que tienes que hacer es: ");
        }
    }
    
}
