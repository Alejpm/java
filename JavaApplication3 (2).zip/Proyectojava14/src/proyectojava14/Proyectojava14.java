
package proyectojava14;

public class Proyectojava14 {

   
    public static void main(String[] args) {
        String[] agendanombre = {"Juan","Jorge","Julia","Jali","Jose"};
       
                
        for(int i = 0;i<agendanombre.length;i++){
        System.out.println("El contenido de la agenda es: "+agendanombre[i]);
    }
    
    }
}
