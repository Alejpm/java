
package proyectojava2;

public class ProyectoJava2 {

    public static void main(String[] args) {
        
        int edad = 20;
        int dia = 4;
        
        System.out.println("Voy a ver si es cierto o no"+(edad > 20 && dia ==5)); //Nos dara false 
        System.out.println("Voy a ver si es cierto o no"+(edad > 19 || dia ==5)); //Nos dara true
    }
    
}
