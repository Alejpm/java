
package proyectojava10;


public class ProyectoJava10 {

   
    public static void main(String[] args) {
    
    int dia = 100;
    while(dia <= 30){
        System.out.println("Hoy es el dia "+dia+" del mes y lo que tienes que hacer es: ");
        dia++;
    }
    
    }
}

