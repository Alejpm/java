package proyectojava16;
import java.io.FileWriter;
import java.io.IOException;
        
public class Proyectojava16 {

    public static void main(String[] args) { 
        
        try{
        
        FileWriter miarchivo = new FileWriter("archivo1.txt");
        miarchivo.write("Hola que sepas que esto se ha escrito desde Java asdfasdfasdfasdf");
        miarchivo.close();
  
    }catch(IOException e){
    e.printStackTrace();
}
    }
}
