package proyectojava13;


public class Persona {
    // Propiedades = variables
    
    int edad = 42;
    String nombre = "Jose Vicente";
    
    // Métodos = funciones
    public void saluda(){
        System.out.println("Hola me llamo"+nombre+" y yo te saludo");
    }
}
