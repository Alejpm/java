
package javaapplication3;

 class JavaApplication3 {

  
    public static void main(String[] args) {
        
        String diadelasemana = "jueves";
        char caracter = 'a';
        char diadelasemanachat = 'v';
        
        System.out.println("La cadena es: "+diadelasemana);
        System.out.println("La cadena es: "+diadelasemana.length());
        System.out.println("La cadena es: "+(diadelasemana.equals("jueves")));
        
        
        
   
    }
    
}
