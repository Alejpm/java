
package proyectojava22;


public class Persona {
    // Voy a declarar propiedades de la clase
    public float x = 400;
    public float y = 200;
    public float direccion = 0;
    
    public void mueveBola(){                                                    // Esta funcion mueve la bola
        double min = -0.5;                                                      // Establezco un mínimo 
        double max = 0.5;                                                       // Establezco un máximo
        double random = min + Math.random() * (max - min);                      // Creo un numero aleatorio entre el mínimo y el máximo
        direccion += random;                                                    // Vario la direccion de forma aleatoria
        x += Math.cos(direccion);                                             // Aumento la x en base a la direccion y su coseno
        y += Math.sin(direccion);                                             // Aumento la y en base a la direccion y su seno
        if(x > 1920){direccion += Math.PI;}                                      // En el caso de que la x sea menor que 400, pega la vuelta
        if(x <0){direccion += Math.PI;}                                         // Pega la vuelta al colisionar
        if(y > 1080){direccion += Math.PI;}                                      // Pega la vuelta al colisionar
        if(y <0){direccion += Math.PI;}                                         // Pega la vuelta al colisionar
    }
    
}
